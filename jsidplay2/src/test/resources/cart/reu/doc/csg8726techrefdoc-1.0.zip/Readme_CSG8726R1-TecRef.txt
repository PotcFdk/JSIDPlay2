The files:
	CSG8726R1-TechnicalReference-1.0.pdf
	CSG8726R1-TechnicalReference-044.odt

consist of a technical description and discussion of the hardware
register interface of the Commodore RAM Expansion Unit (REU). This
technical documentation tries to describe the hardware implementation
aspects of the 8726R1 controller chip of the Commodore REU [8726R1]
as they show up to a programmer.

The document is published under the GNU Free Documentation License:

   Permission is granted to copy, distribute and/or modify this
   document under the terms of the GNU Free Documentation License,
   Version 1.2; with no Invariant Sections, no Front-Cover Texts,
   and no Back-Cover Texts.  A copy of the license is included in
   the appendix section entitled "GNU Free Documentation License".


While the PDF file is the main electronic publishing format, the
file in Open Document Format (*.odf) is the mastering format that
is created with OpenOffice. The mastering file is delivered in
addition to the publishing format to fulfill on of the requirements
of the GNU FDL. To extract raw text from the mastering document,
rename it into a ZIP file (*.zip), extract it and the get the
file content.xml. From that extract all text fragments enclosed by
<text ...> markup.


Wolfgang Moser, 2008-08-02, http://d81.de
