/**
 * Implements hardsid.dll api calls
 * Written by stein.pedersen@hue.no
 */
#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <stdio.h>
#include <string.h>
#ifdef WIN32
  #include <windows.h>
#endif

#if defined linux || __APPLE__
  #define DLLEXPORT __attribute__((visibility("default")))
#elif _MSC_VER
  #define DLLEXPORT __stdcall // We're using a .def file to create undecorated names with __stdcall calling convention
#else
  #define DLLEXPORT __declspec(dllexport) __stdcall
#endif

#define HARDSID_VERSION      0x0203

#define EXSID_MAJOR_VERSION	2
#define EXSID_MINOR_VERSION	1
#define EXSID_REVISION		0

#define EXSID_VERSION		_xxstr(EXSID_MAJOR_VERSION) "." _xxstr(EXSID_MINOR_VERSION) "." _xxstr(EXSID_REVISION)
#define EXSID_VERSION_CHECK(maj, min) ((maj==EXSID_MAJOR_VERSION) && (min<=EXSID_MINOR_VERSION))

#define _xstr(x)	#x
#define _xxstr(x)	_xstr(x)

/** Chip selection values for exSID_chipselect() */
enum {
	XS_CS_CHIP0,	///< 6581
	XS_CS_CHIP1,	///< 8580
	XS_CS_BOTH,	///< Both chips. @warning Invalid for reads: undefined behaviour!
};

/** Audio output operations for exSID_audio_op() */
enum {
	XS_AU_6581_8580,	///< mix: 6581 L / 8580 R
	XS_AU_8580_6581,	///< mix: 8580 L / 6581 R
	XS_AU_8580_8580,	///< mix: 8580 L and R
	XS_AU_6581_6581,	///< mix: 6581 L and R
	XS_AU_MUTE,		///< mute output
	XS_AU_UNMUTE,		///< unmute output
};

/** Clock selection values for exSID_clockselect() */
enum {
	XS_CL_PAL,		///< select PAL clock
	XS_CL_NTSC,		///< select NTSC clock
	XS_CL_1MHZ,		///< select 1MHz clock
};

/** Hardware model return values for exSID_hwmodel() */
enum {
	XS_MD_STD,		///< exSID USB
	XS_MD_PLUS,		///< exSID+ USB
};

enum {
	HSID_USB_WSTATE_OK = 1, HSID_USB_WSTATE_BUSY,
	HSID_USB_WSTATE_ERROR, HSID_USB_WSTATE_END
};

typedef unsigned char Uint8;
typedef unsigned short Uint16;
typedef unsigned char boolean;

#ifdef WIN32
#elif defined(linux) || defined(__APPLE__)

  // Linux way of DLLMain ;-)
  __attribute__((constructor)) void dllLoad() {

  }
#endif

extern "C" {

        // replacement of dllUnload for Linux and macOSX
        void DLLEXPORT HardSID_Uninitialize(void) {
        }

	Uint8 DLLEXPORT HardSID_Read(Uint8 DeviceID, int Cycles, Uint8 SID_reg);

	Uint16 DLLEXPORT HardSID_Version(void) {
		return HARDSID_VERSION;
	}

	Uint8 DLLEXPORT HardSID_Devices(void) {
		return 0;
	}

	void DLLEXPORT HardSID_Delay(Uint8 DeviceID, Uint16 Cycles) {
	}

	void DLLEXPORT HardSID_Write(Uint8 DeviceID, int Cycles, Uint8 SID_reg, Uint8 Data) {
	}

	// Blocking ...
	Uint8 DLLEXPORT HardSID_Read(Uint8 DeviceID, int Cycles, Uint8 SID_reg) {
		return 0;
	}

	void DLLEXPORT HardSID_Flush(Uint8 DeviceID) {
	}

	void DLLEXPORT HardSID_SoftFlush(Uint8 DeviceID) {
	}

	boolean DLLEXPORT HardSID_Lock(Uint8 DeviceID) {
		return true;
	}

	void DLLEXPORT HardSID_Filter(Uint8 DeviceID, boolean Filter) {
	}

	void DLLEXPORT HardSID_Reset(Uint8 DeviceID) {
	}

	void DLLEXPORT HardSID_Sync(Uint8 DeviceID) {
	}

	void DLLEXPORT HardSID_Mute(Uint8 DeviceID, Uint8 Channel, boolean Mute) {
	}

	void DLLEXPORT HardSID_MuteAll(Uint8 DeviceID, boolean Mute) {
	}

	void DLLEXPORT InitHardSID_Mapper(void) {
	}

	Uint8 DLLEXPORT GetHardSIDCount(void) {
		return 0;
	}

	void DLLEXPORT WriteToHardSID(Uint8 DeviceID, Uint8 SID_reg, Uint8 Data) {
	}

	Uint8 DLLEXPORT ReadFromHardSID(Uint8 DeviceID, Uint8 SID_reg) {
		return 0;
	}

	void DLLEXPORT MuteHardSID_Line(int Mute) {
	}

	// DLLs above version 0x0203
	void DLLEXPORT HardSID_Reset2(Uint8 DeviceID, Uint8 Volume) {
	}

	// Unlock the current device to be no more used by the client
	void DLLEXPORT HardSID_Unlock(Uint8 DeviceID) {
	}

	// DLLs version 0x0301 and above

	Uint8 DLLEXPORT HardSID_Try_Write(Uint8 DeviceID, int Cycles, Uint8 SID_reg, Uint8 Data) {
		return HSID_USB_WSTATE_OK;
	}

	// ***********************************************0x202****************************************************
	void DLLEXPORT HardSID_GetSerial(char* output, int bufferSize, Uint8 DeviceID) {
	}
	

}
