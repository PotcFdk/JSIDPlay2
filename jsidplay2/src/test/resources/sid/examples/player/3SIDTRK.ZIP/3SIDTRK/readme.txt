Hi Musicians!!!!!!!

Here is HERMIT SOFTWARE with a new tracker programmmmme made in 2008 Hungary..
Called HERMIT 3SID-TRACKER 2008.


It can control 3 SIDs simultaneously on $d400,$de00,$df00 (yet). 9 polyphony, 3 filters.
(no need arpeggio to have chords)

The tracker itself is a modern fasttracker-like editor, which has additional functions (for
example: the edit cursor and play-cursor,loop-play with F7,etc.).

The player will be improved later, because some functions didn't manage to fit in the 1kb
place for player yet, hard restart is weak (1Frame type).

If someone hasn't 3SID or 2SID machine, 1SID and 2SID versions will be ready in few weeks time.

For help and menu press the up-left corner back key.

My contact: Mih�ly Horv�th (HERMIT SOFT.)
            hmtmade@citromail.hu / hmtmade@gmail.com
            tel.: +36 70 282 5663
	    16 Kast�ly Street, Debrecen-J�zsa, Hungary

If you have ideas or problems, questions, write it me in e-mail or call me. I will help you.

IF YOU LIKE IT AND WRITE MUSIC WITH IT, PLEASE SEND IT TO ME, TO HELP IN IMPROVING.....

HADWARE SOLUTION:
-----------------

To have 3 SID in 1 machine, you must be an electrically qualified person, if you aren't ask
someone to do it. Be careful!


WARNING: DO NOT USE CARTRIDGES IF YOU HAVE THE PLUS SIDS ON DE00-DF00!!!!!!!
-------
Expansion Cartridges (Actio Replay/Others) use the same addresses. 
(IO1,IO2 lines on expansion port)


It's simplest method (I used it too) to sold the 3 MOS8580/6581 SIDs on the otherselves directly.
But you have to bend the CS (Chipselect),CAP1A,CAP1B,CAP2A,CAP2B,AOUIO OUT,AUDIO IN,POTx,
POTY pins (legs marked with *) to make them not to be contacted to the other chips same legs.

The photos of the method are in this .zip called 3sid.jpg


SID PINOUTS: * means that this leg is to separate, and have to be connected to other place
------------					   CONNECTIONS:
		 -------_--------		   -----------
	  CAP1A*-!1*		 28!- Vdd +9V      C1 capacitor (22nF/470pF) to CAP1A-CAP1B
	 	 !		   !
	  CAP1B*-!2*		*27!-*AUDIO OUT    C2 capacitor (22n-470p) to CAP2A-CAP2B
		 !		   !
	  CAP2A*-!3*		*26!-*AUDIO IN	   SID2 CS (Chipsel) to EXP.PORTS 7.pin (IO1)
		 !		   !
	  CAP2B*-!4*		 25!- Vcc +5V	   SID3 CS to expansio port's 10.pin (IO2)
		 !		   !
	 -RESET	-!5		*24!-*POTX	   AUDIO IN,POTx,POTy of SID2 and SID3 is NC
		 !		   !
	  clock -!6		*23!-*POTY	   AUDIO OUT OF SID2 and SID3 to output JACKS
		 !		   !		   that you have to build in.
	   -R/W -!7     SID	 22!- D7	   (I used the DIN5 AV CONNECTION's AUdIO IN)
		 !		   !
	CHIPSEL*-!8*  MOS8580	 21!- D6
		 !		   !
	     A0 -!9  (/mos6581)	 20!- D5
		 !		   !
	     A1 -!10		 19!- D4
		 !		   !
	     A2 -!11		 18!- D3
		 ! 		   !
	     A3	-!12		 17!- D2
		 !		   !
	     A4	-!13		 16!- D1
		 !		   !
	    GND	-!14		 15!- D0
		 ------------------

To REDUCE SID-NOISE affected by VIC you have to use shielded cables to AUDIO OUTs, and
I also changed all buffer-capacitors to 2x size 105C-tempareture types, solded AUDIO IN 
to GND with a capacitor.
But I didn't manage to fully reduce the noise, If someone is there, who managed, 
tell me,how!! 

Thats all now..

I HOPE YOU ENJOY TO USE HMT-3SID TRACKER.......

BYE. 
07.05.2008

READY.
