PLA.EXE

C64 PLA analyzer program / memory map lister

(C)2002-2010 Jens Sch�nfeld - www.icomp.de, www.c64upgra.de
this program is freeware. No part of this archive may be changed.
commercial use is strictly prohibited (with greetings to Alabama)

This archive countains:

PLA.EXE      main program, runs on DOS or in a DOS box
PLA.BIN      binary data, must be in the same directory as PLA.EXE
PLA.PAS      Borland Pascal 5.0 source code
readme.txt   this file

no other files belong here.

This program is provided "as is" with no warranties or liabilities at all. If
you kill your dog with the microwave during the use of this program, it's not
my responsibility. The source is included for educational purpose, please send
me any changes you're making to this thing, or 3d-animated OpenGL versions of
the program :-)

What it does
------------
the program visualizes the C64 memory map depending on the contents of the
$01 register and the external lines of the expansion port.

How to use
----------
Place pla.exe and pla.bin in the same directory and start pla.exe from a
command prompt.
The program should be pretty self-explanatory. Press the keys 0-9, c or q to
toggle the lines or quit. The screen is updated instantly. There is only one
screen. The left column shows the memory map for CPU read accesses, the
middle column shows CPU write accesses, and the right column shows VIC
accesses (which are always read, VIC cannot write!). Loram, Hiram and Charen
are the names of the lower three bits of the $01 register. The screen also
shows a value for the $01 register that sets the shown memory map. The Exrom
and game lines set different memory maps that have different names - these
are also displayed.

Toggling the BA or CAS line will not be of any use to you. Leave them as they
are upon startup of the program. They may be of interest if you know the
internals of the C64 hardware. Also, the . or * after each bank name are not
interesting for you if you don't know the C64 schematics. If you don't
understand it, it's safe to ignore it. If you're a coder, only the three colums
and keys 1-3 are of interest for you.

Why?
----
I have reverse-engineered the PLA chip of the C64, and this program was made
during the process of reverse engineering. The PLA.BIN file is exactly the
one that I have posted to a German newsgroup in August 1994. I found my 
records, and took the time to finally finish my job, since nobody else
really found a nice solution for the casram equation.
PLA replacements have been produced in the meantime. There were minor timing-
issues with the plus/4 version of my "super-PLA", which are now corrected. 
The product uses up-to-date CPLD chips to implement the logic. I have
published the sources of the verified "known good" sources on ftp.funet.fi
(that's C64, 2x 264 series and the 610/710).
The binary images of other PLAs are also published there, just check the 
other archives.

I also found the program useful when coding, that's why I share it with the
community. If you like it, send me an eMail: jens@schoenfeld.de.

bug?
----
The colour ram write line (which is displayed with . or *) is controlled directly
by the PLA. The colour ram is located in the IO space of the CPU, so writing is
turned on during CPU-IO-write cycles. It might sound like a good idea to not
enabe the write line if the IO area is disabled (either with charen=0 or with
Loram=Hiram=0), but this is not done. This is not a bug of this program, it's
how the real C64 PLA behaves, and it's perfectly OK like this. Remember that the
PLA can only make decisions for 4K-windows, so if the CPU writes to an area in
IO space but outside the colour ram, the write line is still enabled, but the
chip is de-selected with the chip-select line. The same happens if the IO space
is switched off, so this is neither a hardware- nor a software-bug. Just a
little weird at first sight.

source
------
The program is written and compiled in Borland Turbo Pascal V5.5, but also compiles
fine with TP5.0 and more modern Delphi compilers. It uses plain DOS or a DOS box of
any compatible operating system (Linux, win9x, Win2k and Win XP confirmed to work). 
I'm a hardware designer. I cannot code. The code is a mess. Take it, laugh
at it, but only send me improvements if you add functionality. I hate to
feel inferior because you solved it in a tenth of the space at 200 times
the speed ;-) There might be useful comments in the source.

history
-------
2002: Initial version made because the C-One prototype had a totally wrong
      PLA.
2003: Cleaned up the source, added this file and released it to ftp.funet.fi
2006: added A12-A15 pull-low option during VIC cycles
      added mode names and a few notes on the screen
2010: polished this readme and finally decided to publish the A12-A15/VIC feature

future
------
When I first published this program in 2003 (2002 version was only given to
Jeri Ellsworth, otherwise the DTV would be even more buggy), I thought it was
complete. However, this new version now adds a new feature that I didn't think
was necessary back then. I might find new things in the (far?) future that let
you investigate even more weird things. 
You may want to port it to some GUI based operating system, add some nice
clicky features, or do the transition from one memory map to another with
3D graphics animations - the fame of being the first is all yours. Just
include all files of this archive unmodified with your work, and make it
available to the community for free. Once again: Commercial use is strictly
prohibited. I don't even allow a "resonable copy-fee" or inclusion in a
"please-register-before-download" database. You either pass this on for free,
or you violate the terms.

thanks
------
- fox/starlight for early betatesting.
- Andreas Boose for early logic reverse-engineering in 1996
- Daniele Gratteri for the 82S100 datasheet PDF
- Marko M�kel� for having maintained ftp.funet.fi for a long time
- Werner van Loo for asking over and over again if I can map in more than
  4K for the VIC with the external GMod cartridge (which lead to this release)
- BeRo for confirming Delphi/Linux compatibility

question
--------
I think I have finally revealed the last secret of the Ultimax mode, and that's
the possibility of switching all ram off for the video chip. This is done with 
several combinations of the upper four address lines, but I cannot see a real
use behind this - especially because feeding the VIC with external data is fairly
complicated and requires rather extreme amounts of logic gates that were
practically out of reach in the early 80's. Did the creator of the PLA chip
really think about freaks like us who create cartridges that do really funny
things to the memory map of the C64?

last words
----------
The reason why so many of you failed on minimizing the CASRAM equation was 
that it's realized active-high in the 82S100 chip. Note that this chip has
ExOR fuses for outputs, and kind-of-a-feedback can be done by multi-using
product terms for multiple outputs (a feature that today's programmable logic
does not have, so you have to do it with real feedbacks, which may result in
timing issues). Also, 5V-tolerant CPLDs are slowly dying out, but we'll surely
find ways to keep the old machines alive. There are lots of SuperPLAs out there
to repair many many C64's on this planet. Even RoHS cannot stop us :-)

--eof
