package test.plugins.macros;

import cml.kickass.plugins.interf.IEngine;
import cml.kickass.plugins.interf.IMacro;
import cml.kickass.plugins.interf.IValue;

public class ErrorMacro implements IMacro{

	@Override
	public String getName() {
		return "Error";
	}

	@Override
	public byte[] execute(IValue[] parameters, IEngine engine) {
		engine.error("This is a test error");
		return null;	// Will not be executed!
	}

}
