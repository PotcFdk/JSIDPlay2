package test.plugins.macros;

import cml.kickass.plugins.interf.IEngine;
import cml.kickass.plugins.interf.IMacro;
import cml.kickass.plugins.interf.IValue;

/***********************************************************************
 * 
 * Name: Mandelbrot
 * 
 * Param: 
 *   re - real koordiante for the center of the image
 *   im - imaginary koordinate for the center of the image
 *   zoom - zoom factor for the image 
 *   iter - maximum number of iterations for the image
 * 
 * Returns:
 *   Bytes that form a mandelbrot fratal as a four color full screen picture
 *   
 * Example:
 *   :Mandelbrot(0,0,4,25) 
 *
 *
 *************************************************************************/

public class MandelbrotMacro implements IMacro {
	@Override
	public String getName() {
		return "Mandelbrot";
	}

	@Override
	public byte[] execute(IValue[] parameters, IEngine engine) {
		// Extract parameters
		double reCenter = parameters[0].getDouble();
		double imCenter = parameters[1].getDouble();
		double zoom = parameters[2].getDouble();
		int maxIter = parameters[3].getInt();

		// Print parameters to the user
		engine.print("Mandelbrot param:");
		engine.print("-----------------");
		engine.print("center = ("+reCenter + ", " + imCenter + ")");
		engine.print("zoom = " + zoom);
		engine.print("max iterations = " + maxIter);
		

		// Draw the fractal
		int i=0;
		byte[] result = new byte[40*25*8];
		for (int screenY=0; screenY<25; screenY++) {
			for (int screenX=0; screenX<40; screenX++) {
				for (int charY=0; charY<8; charY++) {
					int byteValue = 0;
					for (int charX=0; charX<4; charX++){
						int x = charX+screenX*4;
						int y = charY+screenY*8;
						double re = map(x,160,reCenter,zoom);
						double im = map(y,200,imCenter,zoom);
						byteValue = byteValue | (mandelbrot(re,im, maxIter)<<(6-charX*2));			
					}
					result[i++] = (byte)byteValue;
				}
			}
		}
		
		// Return the result
		return result;
	
	}

	private double map(double x, double width, double targetCenter, double targetWidth) {
		return (targetCenter-targetWidth/2) + targetWidth *(x/(width-1)); 
	}


	private int mandelbrot(double re,double im, int maxIterations) {
		double zr = 0;
		double zi = 0; 
	
		int iter=0;
		for(;(zr*zr+zi*zi)<4 && iter<18;iter++) {
			double newZr = zr*zr-zi*zi + re;
			double newZi = 2*zr*zi + im;
			zr = newZr;
			zi = newZi;
		}
		return iter&3; 
	} 
	
}
