package test.plugins.macros;

import cml.kickass.plugins.interf.IEngine;
import cml.kickass.plugins.interf.IMacro;
import cml.kickass.plugins.interf.IValue;

/***********************************************************************
 * 
 * Name: Range
 * 
 * Param: 
 *   Start - start of the range
 *   End - end of the range
 * 
 * Returns:
 *   Bytes in the range given by the parameters
 *   
 * Example:
 *   :Range(5,10) will return the bytes 5,6,7,8,9,10
 *
 *
 *************************************************************************/


public class RangeMacro implements IMacro{

	@Override
	public String getName() {
		return "Range";
	}

	@Override
	public byte[] execute(IValue[] parameters, IEngine engine) {
		// Extract parameters
		if (parameters.length!=2)
			engine.error("Invalid number of parameters. Correct parameters are :Range(start,end)");
		int start = parameters[0].getInt();
		int end = parameters[1].getInt();
		
		// Genereate output
		int length = Math.abs(end-start)+1;
		int step = start<=end ? 1 :-1;
		byte[] result = new byte[length];
		for (int i=0, v=start; i<length; i++, v+=step)  
			result[i]=(byte)v;
		
		// Return output
		return result;
	}

}
