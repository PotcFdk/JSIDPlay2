package test.plugins.packer;

import java.util.ArrayList;
import java.util.List;

import cml.kickass.plugins.interf.IArchive;
import cml.kickass.plugins.interf.IEngine;
import cml.kickass.plugins.interf.IMacro;
import cml.kickass.plugins.interf.IMemoryBlock;
import cml.kickass.plugins.interf.IModifier;
import cml.kickass.plugins.interf.IValue;

/***********************************************************************
 * 
 * Name: PackerArchive
 * 
 * This class demonstates how to make an archive containing  a simple 'packer' modifier. 
 * It puts the the memoryblocks after each other in the memory with a header
 * consisting of a size and a destination.
 *
 *************************************************************************/

public class PackerArchive implements IArchive{

	//------------------------------------------
	// The Archieve interface
	//------------------------------------------
	@Override
	public List<Object> getPluginObjects() {
		List<Object> pluginObjects = new ArrayList<Object>();

		// Add the pack modifier
		pluginObjects.add( new Modifier());
		return pluginObjects;
	}
	
	private class Modifier implements IModifier {
		@Override
		public String getName() {
			return "Pack";
		}
		@Override
		public byte[] execute(List<IMemoryBlock> memoryBlocks, IValue[] parameters, IEngine engine) {
			return pack(memoryBlocks, parameters, engine);
		}
	}
	
	
	//------------------------------------------
	// 'Packer'
	//------------------------------------------
	protected byte[] pack(List<IMemoryBlock> memoryBlocks, IValue[] parameters, IEngine engine) {
		
		// Find size of data
		final int headerSize = 1;	   // 1 byte for number of blocks
		final int blockHeaderSize = 4; // 2 for destination and 2 for size
		
		int dataSize=headerSize; 
		for (IMemoryBlock block : memoryBlocks) {
			dataSize+=blockHeaderSize;	
			dataSize+=block.getBytes().length;
		}
		
		// Setup data array 
		byte[] data= new byte[dataSize];
		int dataPtr=0;
		data[dataPtr++]=(byte)memoryBlocks.size();
		if (memoryBlocks.size()>255) engine.error("Can't handle more than 255 memoryblocks in the same pack");
		

		// Add memory blocks
		for (IMemoryBlock block : memoryBlocks) {
			int address= block.getStartAddress();
			data[dataPtr++]= (byte)(address&0xff);
			data[dataPtr++]= (byte)((address>>8)&0xff);
			
			int length=block.getBytes().length;
			data[dataPtr++]= (byte)(length&0xff);
			data[dataPtr++]= (byte)((length>>8)&0xff);

			for (byte b : block.getBytes()) 
				data[dataPtr++]=b;
		}

		// Return data
		return data;
	} 
}
