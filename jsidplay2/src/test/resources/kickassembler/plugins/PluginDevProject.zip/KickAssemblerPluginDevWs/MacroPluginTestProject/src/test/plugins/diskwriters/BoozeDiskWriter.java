/*
 * A DiskWriter plugin for making disks for the Booze Loader system. 
 *
 * Run the BoozeLoaderArchive example to test. 
 * */


package test.plugins.diskwriters;

import test.lib.BoozeDiskWriterUtil;
import test.lib.BoozeDiskWriterUtil.TrackSector;
import test.lib.ByteBoozer2;
import test.lib.BoozeDiskWriterUtil.FileType;

import java.io.OutputStream;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;

import kickass.common.output.D64Image;
import kickass.plugins.interf.diskwriter.DiskWriterDefinition;
import kickass.plugins.interf.diskwriter.IDiskData;
import kickass.plugins.interf.diskwriter.IDiskFileData;
import kickass.plugins.interf.diskwriter.IDiskWriter;
import kickass.plugins.interf.general.IEngine;
import kickass.plugins.interf.general.IMemoryBlock;
import kickass.plugins.interf.general.IParameterMap;
import kickass.plugins.interf.general.ISourceRange;

public class BoozeDiskWriter implements IDiskWriter {

	// Disk parameter constants
	private static final String diskparam_filename = "filename";
	private static final String diskparam_name = "name";
	private static final String diskparam_id = "id";
	private static final String diskparam_interleave = "interleave"; 
	private static final String diskparam_diskno = "diskno"; 

	// File parameter constants
	private static final String fileparam_name = "name";
	private static final String fileparam_type = "type";
	private static final String fileparam_interleave = "interleave";
	private static final String fileparam_visible = "visible";

	private DiskWriterDefinition definition;
	
	public BoozeDiskWriter() {
		definition=new DiskWriterDefinition();
		definition.setName("BoozeDisk");
		definition.setAllDiskParameters(new HashSet<String>(Arrays.asList(diskparam_filename,diskparam_name, diskparam_id, diskparam_interleave,diskparam_diskno)));
		definition.setNonOptionalDiskParameters(new HashSet<String>(Arrays.asList(diskparam_filename)));
		definition.setAllFileParameters(new HashSet<String>(Arrays.asList(fileparam_name, fileparam_type,fileparam_visible, fileparam_interleave)));
		definition.setNonOptionalFileParameters(new HashSet<String>(Arrays.asList(fileparam_name)));
	} 
	
	@Override
	public DiskWriterDefinition getDefinition() {
		return definition;
	}

	//-----------------------------------------------------------
	// The write method
	//-----------------------------------------------------------
	@Override
	public void execute(IDiskData disk, IEngine engine) {
		
		// Get parameter values
		IParameterMap dparams=disk.getParameters();
		String filename = dparams.getValue(diskparam_filename).getString();
		String name = dparams.getStringValue(diskparam_name, "UNNAMED");
		String id = dparams.getStringValue(diskparam_id,"   2A");
		int defaultInterleave = dparams.getIntValue(diskparam_interleave, 4);
		int diskNo = dparams.getIntValue(diskparam_diskno, 1);

		// Validate interleave
		if (defaultInterleave<0) {
			ISourceRange range = dparams.getSourceRange(diskparam_interleave);
			engine.error("Interleave can't be negative: " + defaultInterleave, range);
		}
		
		// Convert strings to screen codes
		byte[] diskIdBytes = engine.stringToBytes(id);
		byte[] diskNameBytes = engine.stringToBytes(name);

		// Create disk image
		BoozeDiskWriterUtil image = new BoozeDiskWriterUtil(diskNameBytes,diskIdBytes,diskNo, new TrackSector(18, 9));
		

		// Add the files
		for(IDiskFileData file : disk.getFiles())
			addFile(image, file, defaultInterleave, engine);
		
		// Write the file
		engine.printNow("Writing d64 file: "+ filename);
		try {
			OutputStream fout = engine.openOutputStream(filename);
			fout.write(image.generateImage());
			fout.close();
		} catch (D64Image.D64ImageException ex) {
			engine.addError("Error while generating '"+ filename +"': " + ex.getMessage() , null);
		} catch (Exception ex) {
			engine.addError("Error while writing disk '"+filename+"': " + ex.getMessage(), null);
		}
	}
	
	private void addFile(BoozeDiskWriterUtil disk, IDiskFileData file, int defaultInterleave, IEngine engine) {

		IParameterMap fileParam = file.getParameters();

		// Name
		String name = fileParam.getStringValue(fileparam_name,"");	
		byte[] nameBytes = engine.stringToBytes(name);

		// Visible
		boolean isVisible = fileParam.getBoolValue(fileparam_visible, true);

		// Interleave
		int interleave= fileParam.getIntValue(fileparam_interleave, defaultInterleave);
		if (interleave<0) {
			ISourceRange range = fileParam.getSourceRange(fileparam_interleave);
			engine.error("Interleave can't be negative: " + interleave, range);
		}
		
		// Type & locked 
		String typeStr = fileParam.getStringValue(fileparam_type, D64Image.FileType.PRG.toString());
		boolean isLocked = false;
		if (typeStr.endsWith("<")){
			isLocked=true;
			typeStr= typeStr.substring(0, typeStr.length()-1);
		}
		FileType type = getEnum(FileType.class, typeStr);
		if (type==null) 
			engine.error("Unknown type: "+ typeStr, fileParam.getSourceRange(fileparam_name));

		
		// Crunch if its a loaderfile
		List<IMemoryBlock> blocks = file.getMemoryBlocks();
		if (type==FileType.B2L)
			blocks = ByteBoozer2.execute(file.getMemoryBlocks(), engine);
			
		// Add the final file
		byte[] data= blocksToBytes(blocks);

		TrackSector startTs= disk.addFile(nameBytes, type, interleave, data);
		boolean fdir = type==FileType.B2L;
		disk.addDirEntry(isVisible,nameBytes, startTs, type, isLocked, 127, fdir);
	}
	
	private byte[] blocksToBytes(List<IMemoryBlock> blocks) {
		if (blocks.isEmpty())
			return new byte[] {0x00,0x20};
		
		
		// Find min and max address 
		int min = Integer.MAX_VALUE;
		int max = 0;
		for(IMemoryBlock block : blocks) {
			int length = block.getBytes().length;
			if (length==0)
				continue;
			min = Math.min(min, block.getStartAddress());
			max = Math.max(max, block.getStartAddress()+length);
		}
		
		// Setup byte array
		byte[] result = new byte[max-min+2];
		result[0]=(byte)min;
		result[1]=(byte)(min>>>8);

		// Copy blockdata into result array
		for(IMemoryBlock block : blocks ) {
			byte[] blockBytes = block.getBytes();
			System.arraycopy(blockBytes, 0, result, block.getStartAddress()-min+2, blockBytes.length);
		}
		return result;
	}
	
	
	private static <T extends Enum<?>> T getEnum(Class<T> enumeration, String litteralName) {
	    for (T litteral : enumeration.getEnumConstants()) {
	        if (litteral.name().compareToIgnoreCase(litteralName) == 0)
	            return litteral;
	    }
	    return null;
	}
}
