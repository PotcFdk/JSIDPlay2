package test.plugins.macros;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;

import kickass.plugins.interf.general.IEngine;
import kickass.plugins.interf.general.IValue;
import kickass.plugins.interf.macro.IMacro;
import kickass.plugins.interf.macro.MacroDefinition;

/***********************************************************************
 * 
 * Name: Import
 * 
 * Param: 
 * 	 Filename - the name of the file to import	
 *   Start - start index of the imported bytes
 *   End - end index of the imported bytes
 * 
 * Returns:
 *   The bytes in the indexed range of the file
 *   
 * Example:
 *   :Import("myfile.bin", 5,10) will return the byte 5 to 9 of the the file
 *
 *************************************************************************/


public class ImportMacro implements IMacro {

	private MacroDefinition definition;
	
	public ImportMacro() {
		definition=new MacroDefinition();
		definition.setName("Import");
	}
	
	@Override
	public MacroDefinition getDefinition() {
		return definition;
	}

	@Override
	public byte[] execute(IValue[] parameters, IEngine engine) {
		// Extract parameters
		if (parameters.length!=3)
			engine.error("Invalid number of parameters. Correct parameters are :Import(filename,startOffsetInFile,endOffsetInFile)");
		String filename = parameters[0].getString();
		int start = parameters[1].getInt();
		int end = parameters[2].getInt();
		if (start<0) engine.error("Start cant be negative : "+ start);
		
		// Read the file
		File file = engine.getFile(filename);
		if (file==null) engine.error("Can't open file: "+filename);
		byte[] fileBytes = new byte[(int)file.length()];
		try {
			InputStream is = new FileInputStream(file);
			is.read(fileBytes);
			is.close();
		} catch(Exception ex) {
			engine.error("Error while reading file :" + ex.getMessage());
		}
		
		// Check ranges against the file size
		int resultLength = Math.max(0, end-start);
		if (resultLength==0) return null; 
		if (start>=file.length()) engine.error("Start index is greater than the file size: "+ start);
		if (start+resultLength>=file.length()) engine.error("The indexed range exceeds the filesize");
	
		// Create and return the output bytes
		byte[] result = new byte[resultLength];
		for (int i=0;i<resultLength; i++)
			result[i]= fileBytes[start+i];
		return result;
	}

}
