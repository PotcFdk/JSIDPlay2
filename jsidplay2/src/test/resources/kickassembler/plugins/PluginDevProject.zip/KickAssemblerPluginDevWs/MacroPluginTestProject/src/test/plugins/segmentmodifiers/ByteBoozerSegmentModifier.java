package test.plugins.segmentmodifiers;

import java.util.List;

import kickass.plugins.interf.general.IEngine;
import kickass.plugins.interf.general.IMemoryBlock;
import kickass.plugins.interf.general.IValue;
import kickass.plugins.interf.segmentmodifier.ISegmentModifier;
import kickass.plugins.interf.segmentmodifier.SegmentModifierDefinition;

public class ByteBoozerSegmentModifier implements ISegmentModifier {

	private SegmentModifierDefinition definition; 

	public ByteBoozerSegmentModifier() {
		definition = new SegmentModifierDefinition();
		definition.setName("ByteBoozer");
	}
	
	@Override
	public SegmentModifierDefinition getDefinition() {
		return definition;
	}

	
	@Override
	public List<IMemoryBlock> execute(List<IMemoryBlock> arg0, List<IValue> arg1, IEngine arg2) {
		return null;
	}

}
