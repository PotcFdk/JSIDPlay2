package test.plugins.segmentmodifiers;

import java.util.ArrayList;
import java.util.List;

import kickass.plugins.interf.general.IEngine;
import kickass.plugins.interf.general.IMemoryBlock;
import kickass.plugins.interf.general.IValue;
import kickass.plugins.interf.segmentmodifier.ISegmentModifier;
import kickass.plugins.interf.segmentmodifier.SegmentModifierDefinition;

/***********************************************************************
 * 
 * Name: Delta
 * 
 * Arguments: None
 *
 * This simple example segment modifier changes the bytes of a segment to be the delta values
 * instead of absolute values. Eg. the sequence 1,2,3,4,4,4,4 will become 1,1,1,1,0,0,0 
 * (Pretty useless, but this is an example)
 *
 *************************************************************************/


public class DeltaSegmentModifier implements ISegmentModifier {

	private SegmentModifierDefinition definition; 

	public DeltaSegmentModifier() {
		definition = new SegmentModifierDefinition();
		definition.setName("Delta");
	}
	
	@Override
	public SegmentModifierDefinition getDefinition() {
		return definition;
	}
	
	@Override
	public List<IMemoryBlock> execute(List<IMemoryBlock> blocks, List<IValue> args, IEngine engine) {
		
		ArrayList<IMemoryBlock> result = new ArrayList<>();
		
		for(IMemoryBlock block : blocks) {
			
			// Create deltabytes 
			byte[] bytes = new byte[block.getBytes().length];
			int i=0;
			byte prevValue=0;
			for(byte b : block.getBytes()) {
			    bytes[i++]=(byte)(b-prevValue);
				prevValue = b;
			}
			
			// Add new block to result
			IMemoryBlock newBlock = engine.createMemoryBlock(block.getName(), block.getStartAddress(), bytes);
			result.add(newBlock);
		} 

		return result;
	}

}
