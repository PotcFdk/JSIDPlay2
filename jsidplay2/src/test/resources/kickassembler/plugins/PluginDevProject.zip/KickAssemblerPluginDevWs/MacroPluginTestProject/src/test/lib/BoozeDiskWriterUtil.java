/**********************************************************
 * 
 * BoozeDiskWriterUtil  
 * 
 * A rewritten version of David Malmborg disk writer util 
 * used for the BoozeLoader system.  
 * 
 * Note: This was made for a proof of concept of 
 * DiskLoadSystem support in Kick Assembler. It might contain
 * bugs. For a maintained version of the Booze Loader system 
 * you are referred to P-a Backstrom's excellent plugins.    
 * 
 **********************************************************/

package test.lib;

import java.util.Arrays;

public class BoozeDiskWriterUtil {
	private Track[] tracks;
	
	private int nextDirEntry = 0;
	private TrackSector nextTs = new TrackSector(1, 0);
	private TrackSector fastDirTs;
	private int fastDirOffset = 0;
	
	
	public BoozeDiskWriterUtil(byte[] name, byte[] id, int diskNo, TrackSector fdirTs) {
				
		this.fastDirTs = fdirTs;

		// Setup tracks
		int noOfTracks=35;
		tracks = new Track[noOfTracks];
		int i=1; 
		for(;i<=17;i++) tracks[i-1] = new Track(21); 
		for(;i<=24;i++) tracks[i-1] = new Track(19); 
		for(;i<=30;i++) tracks[i-1] = new Track(18); 
		for(;i<=noOfTracks;i++) tracks[i-1] = new Track(17); 

		// Setup bam sector
		markSectorAsUsed(18, 0);
		byte[] bam = getSector(18, 0);
		bam[0]=(byte)18; 								// Track with first dirEntry
		bam[1]=(byte)1;  								// Sector with first dirEntry
		bam[2]=(byte)0x41;								// DOS version type
		Arrays.fill(bam,0xa0,0xaa, (byte)0xa0); 			// Some padding
		copyAndPad(name, bam, 0x90, 16, (byte)0xa0);		// Name
		copyAndPad(id, bam, 0xa2, 5, (byte)0xa0);		// ID
		bam[0xff] = (byte)diskNo;


		// Fast dir
		if (fastDirTs!=null) {
			markSectorAsUsed(fastDirTs.track, fastDirTs.sector);
		}
	}
	
	private void copyAndPad(byte[] src, byte[] dest, int destOffset, int length, byte pad ) {
		int cutLength = Math.min(length, src.length);
		System.arraycopy(src, 0, dest, destOffset, cutLength);
		for (int i=cutLength; i<length; i++)
			dest[destOffset+i]=pad;
	}
 
	private byte[] getSector(int track, int sector) {
		return tracks[track-1].sectors[sector];
	}
	private boolean isSectorFree(int track, int sector) {
		return tracks[track-1].sectorIsFree[sector];
	}
	
	private int getNoOfSectors(int track) {
		return tracks[track-1].noOfSectors;
	} 
	
	private void markSectorAsUsed(int track, int sector) {
		tracks[track-1].sectorIsFree[sector] = false;
	}
	
	public TrackSector addFile(byte[] name, FileType type, int interleave, byte[] data) {
		TrackSector startTs = findFreeSector(nextTs,1);

		int bytesPrSector = 254; // 256 in raw mode
		int noOfSectors = 1+(data.length / bytesPrSector); 
	
		// Write sectors
		TrackSector ts = startTs;
		int dataOffset=0;
		for (int i=0; i<noOfSectors;i++) {
			ts = findFreeSector(ts, interleave);
	//		System.out.println("Writing sector "+ts.track+","+ts.sector);
			markSectorAsUsed(ts.track, ts.sector);
			
			byte[] sector = getSector(ts.track, ts.sector);
			
			// Set nextTs
			int byteOnSector = Math.min(bytesPrSector, data.length-dataOffset);
			boolean isLastSector = i==noOfSectors-1;
			if (!isLastSector) {
				TrackSector nextTs = findFreeSector(ts,interleave);
				sector[0] = 	(byte)nextTs.track;
				sector[1] = 	(byte)nextTs.sector;
			} else {
				sector[0] = 	(byte)0;
				sector[1] = 	(byte)(byteOnSector+2);
			}

			// Copy bytes 
			System.arraycopy(data, dataOffset, sector, 2, byteOnSector);
			dataOffset+=byteOnSector;
		}
		
		// Set next Ts 
		nextTs = new TrackSector(ts.track, ts.sector+interleave);
		return startTs;
	}

	
	
	private TrackSector findFreeSector(TrackSector startTs, int interleave) {
		int track = startTs.track;
		int sector = startTs.sector;
		while (true) {
			// Detect out of diskspace
			if (track-1>tracks.length)
				return null;
			
			// Search for sector on track 
			int sectorsOnTrack = getNoOfSectors(track);
			for (int i=0; i<sectorsOnTrack; i++) {
				int testSector = (sector+i*interleave) % sectorsOnTrack;
				if (isSectorFree(track, testSector))
					return new TrackSector(track,testSector);
			}
			
			// Sector not found, try on next track 
			track++;
			sector=0;
			if (track==18)
				track++;
		}
	} 
	
	public void addDirEntry(boolean isVisible, byte[] filename, TrackSector startTs, FileType type, boolean isLocked, int noOfSectors, boolean fdir) {
		// Add fastDir
		if (fastDirTs!=null && fdir) {
			byte[] sector=getSector(fastDirTs.track,fastDirTs.sector);
			sector[fastDirOffset++]=(byte)startTs.track;
			sector[fastDirOffset++]=(byte)startTs.sector;
		}
		
		if (!isVisible)
			return;
		
		// Find sector+offset (entriesPrTrack=8)
		int dirSectorNo = 1+(nextDirEntry>>3);
		byte[] sector=getSector(18,dirSectorNo); 
		int offset=(nextDirEntry & 0x7)*0x20;
		nextDirEntry++;

		// Mark sector as used
		markSectorAsUsed(18, dirSectorNo);

		// Set link to next dir entry sector
		sector[offset+0] = (byte) (offset!=0 ? 0 : 18);
		sector[offset+1] = (byte) (offset!=0 ? 0 : dirSectorNo+1);

		// Type, startTrack, startSector
		sector[offset+2] = (byte)(type.id | (isLocked?0x40:0));
		sector[offset+3] = (byte)startTs.track;
		sector[offset+4] = (byte)startTs.sector;

		// Filename
		copyAndPad(filename, sector, offset+5, 16, (byte)0xa0);
	
		// Filesize
		sector[offset+0x1e] = (byte)(noOfSectors&255);
		sector[offset+0x1f] = (byte)(noOfSectors>>8);
	}

	public byte[] generateImage() {

		// Generate free sectormap in bam
		byte[] bam = getSector(18, 0);
		int bamOffset=4;
		for(Track track : tracks) {
			int freeSectors=0;
			int bamBits=0;
			int mask=1;
			for (boolean sectorIsFree : track.sectorIsFree) {
				if (sectorIsFree) freeSectors++;
				bamBits|= (sectorIsFree?0xffffff:0)&mask;
				mask=mask<<1;
			}
			bam[bamOffset]=(byte)freeSectors;
			bam[bamOffset+1]=(byte)(bamBits>>0);
			bam[bamOffset+2]=(byte)(bamBits>>8);
			bam[bamOffset+3]=(byte)(bamBits>>16);
			bamOffset+=4;
		}
				
		// Find size of disk 
		int noOfBytes = 0;
		for (Track track : tracks)
			noOfBytes+= 256*track.noOfSectors;
		
		// Copy bytes to array
		int pos=0;
		byte[] result = new byte[noOfBytes];
		for (Track track : tracks) {
			for (byte sector[] : track.sectors) {
				System.arraycopy(sector, 0, result, pos, 256);
				pos+=256;
			}
		}
		
		// Return result
		return result; 
	}
	
	static public class TrackSector {
		int track;
		int sector;
		public TrackSector(int track, int sector) {
			this.track = track;
			this.sector = sector;
		}
	}

	static public enum FileType {
		DEL(0x80),
		SEQ(0x81),
		PRG(0x82),
		B2L(0x82),  // ByteBoozer2LoaderFile
		USR(0x83),
		REL(0x84);

		public int id;

		FileType(int id) {
			this.id = id;
		}
	}

	
}


class Track {
	public int noOfSectors;
	public byte[][] sectors;
	public boolean[] sectorIsFree;

	public Track(int noOfSectors) {
		this.noOfSectors = noOfSectors;
		this.sectors = new byte[noOfSectors][256];
		this.sectorIsFree = new boolean[noOfSectors];
		Arrays.fill(sectorIsFree, true);
	}
}


