package test.plugins.modifiers;

import java.util.List;

import kickass.plugins.interf.general.IEngine;
import kickass.plugins.interf.general.IMemoryBlock;
import kickass.plugins.interf.general.IValue;
import kickass.plugins.interf.modifier.IModifier;
import kickass.plugins.interf.modifier.ModifierDefinition;

/***********************************************************************
 * 
 * Name: Pack
 * 
 * Arguments: None
 *
 * This example modifier packs the included memory blocks in the byte format:
 * 
 *    Header: NoOfBlocks, 
 *    Block1: Start_lo, Start_hi, Size_lo, Size_hi, data....  
 *    Block2: Start_lo, Start_hi, Size_lo, Size_hi, data....  
 *    Block3: Start_lo, Start_hi, Size_lo, Size_hi, data....  
 *    ....
 *
 *
 * Note: Modifiers is the old way of doing things. Consider using SegmentModifiers instead.   
 *************************************************************************/

public class PackerModifier implements IModifier {

	private ModifierDefinition definition;
	
	public PackerModifier() {
		definition = new ModifierDefinition();
		definition.setName("Pack");
	}
		
	@Override
	public ModifierDefinition getDefinition() {
		return definition;
	}

		
	@Override
	public byte[] execute(List<IMemoryBlock> memoryBlocks, IValue[] parameters, IEngine engine) {
		
		// Find size of data
		final int headerSize = 1;	   // 1 byte for number of blocks
		final int blockHeaderSize = 4; // 2 for destination and 2 for size
		
		int dataSize=headerSize; 
		for (IMemoryBlock block : memoryBlocks) {
			dataSize+=blockHeaderSize;	
			dataSize+=block.getBytes().length;
		}
		
		// Setup data array 
		byte[] data= new byte[dataSize];
		int dataPtr=0;
		data[dataPtr++]=(byte)memoryBlocks.size();
		if (memoryBlocks.size()>255) engine.error("Can't handle more than 255 memoryblocks in the same pack");
		

		// Add memory blocks
		for (IMemoryBlock block : memoryBlocks) {
			int address= block.getStartAddress();
			data[dataPtr++]= (byte)(address&0xff);
			data[dataPtr++]= (byte)((address>>8)&0xff);
			
			int length=block.getBytes().length;
			data[dataPtr++]= (byte)(length&0xff);
			data[dataPtr++]= (byte)((length>>8)&0xff);

			for (byte b : block.getBytes()) 
				data[dataPtr++]=b;
		}

		// Return data
		return data;
	}
}
