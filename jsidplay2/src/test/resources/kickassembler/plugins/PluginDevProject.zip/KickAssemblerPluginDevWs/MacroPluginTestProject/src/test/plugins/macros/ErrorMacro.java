package test.plugins.macros;

import kickass.plugins.interf.general.IEngine;
import kickass.plugins.interf.general.IValue;
import kickass.plugins.interf.macro.IMacro;
import kickass.plugins.interf.macro.MacroDefinition;

/***********************************************************************
 * 
 * A simple macro that prints an error
 * 
 * Name: Error
 * 
 *************************************************************************/


public class ErrorMacro implements IMacro {
	
	@Override
	public MacroDefinition getDefinition() {
		MacroDefinition definition = new MacroDefinition();	
		definition.setName("Error");
		return definition;
	}


	@Override
	public byte[] execute(IValue[] parameters, IEngine engine) {
		engine.error("This is a test error");
		return null;	// Will not be executed!
	}


}
