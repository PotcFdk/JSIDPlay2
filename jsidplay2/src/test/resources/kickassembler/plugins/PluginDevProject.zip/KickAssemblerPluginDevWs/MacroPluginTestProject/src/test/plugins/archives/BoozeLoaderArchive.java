package test.plugins.archives;

import java.util.ArrayList;
import java.util.List;

import kickass.plugins.interf.IPlugin;
import kickass.plugins.interf.archive.IArchive;
import kickass.plugins.interf.autoincludefile.AutoIncludeFile;
import test.plugins.diskwriters.BoozeDiskWriter;

public class BoozeLoaderArchive implements IArchive{

	@Override
	public List<IPlugin> getPluginObjects() {
		ArrayList<IPlugin> plugins = new ArrayList<>(); 
		
		// Include the diskwriter
		plugins.add(new BoozeDiskWriter());
		
		// Include sourcefile with macros (Will automatically be loaded)
		plugins.add(new AutoIncludeFile("TestArchive.jar",getClass(),"/include/boozeloader/LoaderInstall.asm"));
		plugins.add(new AutoIncludeFile("TestArchive.jar",getClass(),"/include/boozeloader/LoaderRuntime.asm"));
		return plugins;
	}
}
