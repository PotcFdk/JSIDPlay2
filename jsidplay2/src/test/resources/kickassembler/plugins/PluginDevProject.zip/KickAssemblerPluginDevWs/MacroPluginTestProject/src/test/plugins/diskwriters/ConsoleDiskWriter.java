/**
 *  Simple diskwriter that picks up the disk data and write it to the console
 */

package test.plugins.diskwriters;

import java.util.Arrays;
import java.util.HashSet;

import kickass.plugins.interf.diskwriter.DiskWriterDefinition;
import kickass.plugins.interf.diskwriter.IDiskData;
import kickass.plugins.interf.diskwriter.IDiskFileData;
import kickass.plugins.interf.diskwriter.IDiskWriter;
import kickass.plugins.interf.general.IEngine;
import kickass.plugins.interf.general.IMemoryBlock;
import kickass.plugins.interf.general.IParameterMap;

public class ConsoleDiskWriter implements IDiskWriter{

	private DiskWriterDefinition definition;
	
	
	public ConsoleDiskWriter() {
		definition = new DiskWriterDefinition();
		definition.setName("Console");
		
		// Define the parameters for the disk 
		definition.setAllDiskParameters(new HashSet<>(Arrays.asList("name")));
		definition.setNonOptionalDiskParameters(new HashSet<>(Arrays.asList())); // Note - name is optional
		
		// Define the parameters for the files 
		definition.setAllFileParameters(new HashSet<>(Arrays.asList("name", "type")));
		definition.setNonOptionalFileParameters(new HashSet<>(Arrays.asList("name")));  // Note - type is optional
		
	}
	
	@Override
	public DiskWriterDefinition getDefinition() {
		return definition;
	}

	@Override
	public void execute(IDiskData diskData, IEngine engine) {
		
		String diskName = diskData.getParameters().getStringValue("name", "Unnamed");

		engine.printNow("-----");
		engine.printNow("DiskName is: "+diskName);
		int fileNo=1;
		for(IDiskFileData file : diskData.getFiles()) {
			// Get name and type
			IParameterMap fparams = file.getParameters();
			String filename = fparams.getStringValue("name", null);
			String type = fparams.getStringValue("type", "prg");
			
			// Count data-bytes
			int noOfBytes = 0;
			for (IMemoryBlock block : file.getMemoryBlocks())
				noOfBytes+=block.getBytes().length;
			
			// Print file data
			engine.printNow(String.format("File %s, name=\"%s\", type=%s, noOfBytes=%s", fileNo++,filename,type,noOfBytes));
		}		
	}
}
