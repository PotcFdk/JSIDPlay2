package se.triad.kickass;

public class CrunchedObject {
	
	public final byte[] data;
	public final int address;
	
	public CrunchedObject(byte[] data, int address){
		this.data = data;
		this.address = address;
	}
	
}