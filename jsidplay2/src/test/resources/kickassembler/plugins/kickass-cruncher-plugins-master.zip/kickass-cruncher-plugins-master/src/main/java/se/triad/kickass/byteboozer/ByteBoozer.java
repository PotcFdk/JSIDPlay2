package se.triad.kickass.byteboozer;

@Deprecated
public class ByteBoozer extends se.booze.byteboozer.ByteBoozer {

}
