package se.triad.kickass;

@Deprecated
public class CruncherPlugins extends se.booze.kickass.CruncherPlugins{

}
