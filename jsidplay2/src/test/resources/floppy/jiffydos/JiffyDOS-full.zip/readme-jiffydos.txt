JiffyDOS_C1541.bin is a 16K file, for the 1541

JiffyDOS_1541.bin is the upper half, and replaces 901229-0x on older 1541 drives.


For the 1581 ROM use a 27(C)256.  The Original 1581 ROM is 318045-01 aka 312558-01.  318045-02.bin fixes a few bugs.   

