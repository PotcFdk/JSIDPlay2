#!/usr/bin/bash

cd src
../tools/acme.exe main.asm
../tools/acme.exe main-reu.asm
../tools/acme.exe docs.asm
cd ..
./tools/exomizer.exe sfx sys -o "rev5-exo.prg" "rev5.prg"
./tools/exomizer.exe sfx sys -o "rev5 reu-exo.prg" "rev5 reu.prg"
./tools/exomizer.exe sfx sys -o "rev5 docs-exo.prg" "rev5 docs.prg"
mv -f "rev5-exo.prg" "rev5.prg"
mv -f "rev5 reu-exo.prg" "rev5 reu.prg"
mv -f "rev5 docs-exo.prg" "rev5 docs.prg"
./tools/C1541.exe -format v-max\!,lc d64 Revolution-V.d64 -attach Revolution-V.d64 -write "rev5.prg" "rev5" -write "rev5 reu.prg" "rev5 reu" -write "rev5 docs.prg" "rev5 docs"
#./tools/nibwrite.exe Revolution-V.d64
